import os
import json

from google.cloud import storage
from google.cloud import datastore
from google.cloud import pubsub_v1


def loader(event, context):
    """Triggered by a change to a Cloud Storage bucket.
    Args:
         event (dict): Event payload.
         context (google.cloud.functions.Context): Metadata for the event.
    """
    try:
        file_name = event['name']
        bucket_name = event['bucket']

        client = storage.Client()

        bucket = client.get_bucket(bucket_name)
        file_blob = storage.Blob(file_name, bucket)
        data = file_blob.download_as_string().decode()

        for line in data.splitlines()[1:]:
            id, name, dept = tuple(line.split(','))
            email = f'{name}.{id}@example.com'
            emp = {'id': id,
                   'name': name,
                   'dept': dept,
                   'email': email}
            add_into_datastore(emp)
            publish_to_topic(emp)
    except Exception as e:
        print(e)


def add_into_datastore(data):
    client = datastore.Client()

    key = client.key('employee', data["id"])
    task = datastore.Entity(key=key)

    task.update(data)
    client.put(task)


def publish_to_topic(data):
    project_id = os.environ.get('GCP_PROJECT')
    topic_id = os.environ.get('TOPIC_NAME')

    publisher = pubsub_v1.PublisherClient()
    topic_path = publisher.topic_path(project_id, topic_id)
    data = json.dumps(data).encode("utf-8")
    response = publisher.publish(topic_path, data=data)
    print(response.result())
